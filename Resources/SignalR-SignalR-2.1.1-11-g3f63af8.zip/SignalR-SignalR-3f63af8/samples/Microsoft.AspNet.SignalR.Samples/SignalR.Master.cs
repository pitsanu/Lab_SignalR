﻿using System;

namespace Microsoft.AspNet.SignalR.Samples
{
    public partial class SignalRMaster : System.Web.UI.MasterPage
    {
        protected void Page_Load(object sender, EventArgs e)
        {

        }
    }
}
