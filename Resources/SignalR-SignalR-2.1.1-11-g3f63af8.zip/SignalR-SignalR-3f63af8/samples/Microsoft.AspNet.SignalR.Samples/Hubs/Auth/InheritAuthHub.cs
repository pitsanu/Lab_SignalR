﻿using Microsoft.AspNet.SignalR.Hubs;

namespace Microsoft.AspNet.SignalR.Samples.Hubs.Auth
{
    public class InheritAuthHub : AuthHub
    {
    }
}