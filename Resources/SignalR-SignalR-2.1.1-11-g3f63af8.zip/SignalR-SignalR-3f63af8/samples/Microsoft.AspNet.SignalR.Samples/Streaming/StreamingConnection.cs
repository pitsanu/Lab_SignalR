﻿using System.Collections.Generic;

namespace Microsoft.AspNet.SignalR.Samples
{
    public class StreamingConnection : PersistentConnection
    {
    }
}