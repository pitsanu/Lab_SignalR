#!/usr/bin/env bash
export EnableNuGetPackageRestore="true"
xbuild Microsoft.AspNet.SignalR.Mono.sln
