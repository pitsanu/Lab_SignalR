﻿// Copyright (c) Microsoft Open Technologies, Inc. All rights reserved. See License.md in the project root for license information.

using System.Reflection;

[assembly: AssemblyTitle("Microsoft.AspNet.SignalR.Client.Portable")]
[assembly: AssemblyDescription("Portable client for SignalR targeting WinRT, SL and WP")]

