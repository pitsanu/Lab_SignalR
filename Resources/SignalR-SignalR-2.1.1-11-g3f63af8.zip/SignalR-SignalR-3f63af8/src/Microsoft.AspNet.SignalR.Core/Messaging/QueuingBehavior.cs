﻿namespace Microsoft.AspNet.SignalR
{
    public enum QueuingBehavior
    {
        InitialOnly,
        Always,
        Disabled
    }
}

